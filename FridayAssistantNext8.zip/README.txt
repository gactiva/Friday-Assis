Friday/Jarvis Assistant - Version 8 source

New in this version:
- App UI lets you select Friday or Jarvis separately.
- Friday uses the device's default voice / attempts a female-labelled voice if the TTS engine exposes one.
- Jarvis requests a male-labelled voice, with lower-pitch fallback.
- Choose English or Hindi mode separately. Speech recognition and responses use the selected language; this is not automatic simultaneous bilingual detection.
- Commands require the selected wake word: Friday in Friday mode, Jarvis in Jarvis mode.
- Add "over" at the end of a command (example: "Jarvis, open YouTube, over"). "Over" is stripped from the command.
- Background sound is ignored unless the selected wake word is recognized, but speech recognition can still mishear noise.

Build:
- Upload this ZIP to the GitHub repository.
- Set the workflow extraction command to: unzip -o FridayAssistantNext8.zip -d project
- Build using GitHub Actions.

Limitations:
- This source ZIP has not been compiled or tested on a physical device in this environment.
- Android SpeechRecognizer generally depends on the installed speech service and may use network processing.
- Male/female voice selection depends on voices provided by the phone's TTS engine; some engines do not label voice gender reliably.
- "Over" is a spoken end marker within the same recognized utterance, not a guaranteed acoustic noise gate.
- For privacy, stop the service when not in use. Android foreground-service notification remains visible.

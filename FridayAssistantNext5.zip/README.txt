Friday Assistant Next 5 - smarter wake words and bilingual command prototype

Based on the background-listening project that was previously provided.

Changes:
- Wake phrase handling for both Friday and Jarvis, plus common recognition variants.
- Alternates Android speech recognition between English (India) and Hindi (India).
- Adds basic Hindi/Hinglish intents for common phone actions.
- Attempts to use an installed TTS voice labelled male when the device exposes one; otherwise uses a lower pitch as a best-effort deeper voice.
- Existing Start/Stop buttons and foreground listening service are retained.

Important limitations:
- Android SpeechRecognizer generally relies on the phone's speech-recognition provider and network/configuration; this is not guaranteed to work offline.
- Alternating languages improves language coverage but can miss a phrase if the wrong language is active for that turn.
- A male voice cannot be guaranteed on every device. Available voices depend on Android Text-to-Speech engine and installed language data.
- This is a prototype; build and test it before replacing the working APK.

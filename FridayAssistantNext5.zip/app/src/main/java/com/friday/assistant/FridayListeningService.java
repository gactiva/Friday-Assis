\
package com.friday.assistant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.*;
import java.text.SimpleDateFormat;

public class FridayListeningService extends Service implements RecognitionListener {
    private static final String CH = "friday_listening";
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private Handler h = new Handler(Looper.getMainLooper());
    private boolean running = false, speaking = false;
    private boolean useHindiNext = false;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Friday listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while Friday listens");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) configureVoice();
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(this);
        }
    }

    private void configureVoice() {
        // Prefer a voice explicitly labelled male when the installed TTS engine exposes one.
        // Otherwise use a lower pitch as a best-effort deeper voice; actual voice depends on the phone's TTS engine.
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            if (voices != null) {
                for (Voice v : voices) {
                    String n = v.getName().toLowerCase(Locale.ROOT);
                    Locale l = v.getLocale();
                    boolean supportedLanguage = l != null && (
                        l.getLanguage().equals("en") || l.getLanguage().equals("hi"));
                    if (supportedLanguage && (n.contains("male") || n.contains("masculine"))) {
                        best = v;
                        break;
                    }
                }
            }
            if (best != null) tts.setVoice(best);
            else tts.setLanguage(new Locale("en", "IN"));
            tts.setPitch(0.82f);
            tts.setSpeechRate(0.92f);
        } catch (Exception ignored) {
            try { tts.setLanguage(new Locale("en", "IN")); tts.setPitch(0.82f); } catch (Exception ignoredAgain) {}
        }
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        running = true;
        Intent open = new Intent(this, MainActivity.class);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pf |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, pf);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        Notification n = nb.setContentTitle("Friday / Jarvis is listening")
            .setContentText("Say “Friday” or “Jarvis” to give a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
        startForeground(4401, n);
        listen();
        return START_STICKY;
    }

    private void listen() {
        if (!running || speaking || sr == null) return;
        h.postDelayed(() -> {
            if (!running || speaking || sr == null) return;
            try {
                // Alternate English (India) and Hindi recognition to support either language.
                Locale locale = useHindiNext ? new Locale("hi", "IN") : new Locale("en", "IN");
                useHindiNext = !useHindiNext;
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag());
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale.toLanguageTag());
                i.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                sr.startListening(i);
            } catch (Exception e) {
                restart(1500);
            }
        }, 450);
    }

    private void restart(long d) { if (running) h.postDelayed(this::listen, d); }

    @Override public void onResults(Bundle b) {
        ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (a != null) {
            for (String candidate : a) {
                if (candidate != null && handle(candidate)) break;
            }
        }
        restart(700);
    }

    @Override public void onError(int e) { restart(1000); }
    @Override public void onReadyForSpeech(Bundle b) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float r) {}
    @Override public void onBufferReceived(byte[] b) {}
    @Override public void onEndOfSpeech() {}
    @Override public void onEvent(int e, Bundle b) {}
    @Override public void onPartialResults(Bundle b) {}

    private boolean handle(String text) {
        String q = text.toLowerCase(Locale.ROOT).trim();
        // English/Hindi transliteration variants commonly returned by phone speech engines.
        String wakePattern = ".*\\b(friday|fri day|fridai|freddie|jarvis|jarvisse|जार्विस|फ्राइडे|फ्राइडे)\\b.*";
        if (!q.matches(wakePattern) && !q.contains("जार्विस") && !q.contains("फ्राइडे")) return false;

        String c = q.replaceFirst(".*?(friday|fri day|fridai|freddie|jarvis|jarvisse|जार्विस|फ्राइडे)", "")
                    .replaceAll("^[ ,.!?，。]+", "").trim();
        if (c.isEmpty()) {
            say(q.contains("जार्विस") || q.contains("jarvis") ? "Yes, sir. How can I help?" : "Yes? What can I do for you?");
            return true;
        }
        command(c);
        return true;
    }

    private void command(String raw) {
        String q = raw.toLowerCase(Locale.ROOT).trim();
        // Normalize common Hindi/Hinglish command phrases to the same intents as English.
        if (containsAny(q, "youtube", "यूट्यूब")) { url("https://www.youtube.com"); return; }
        if (containsAny(q, "google", "search", "browser", "chrome", "गूगल", "सर्च", "खोलो गूगल", "इंटरनेट")) { url("https://www.google.com"); return; }
        if (containsAny(q, "whatsapp", "व्हाट्सएप", "व्हाट्सऐप")) { pkg("com.whatsapp", "I could not find WhatsApp."); return; }
        if (containsAny(q, "camera", "photo", "कैमरा", "फोटो")) { intent(new Intent("android.media.action.IMAGE_CAPTURE"), "I could not open Camera."); return; }
        if (containsAny(q, "settings", "सेटिंग", "सेटिंग्स")) { intent(new Intent(android.provider.Settings.ACTION_SETTINGS), "I could not open Settings."); return; }
        if (containsAny(q, "maps", "navigation", "मैप", "मैप्स", "रास्ता")) { url("https://maps.google.com"); return; }
        if (containsAny(q, "calculator", "कैलकुलेटर", "गणना")) { intent(new Intent("android.intent.action.MAIN").addCategory("android.intent.category.APP_CALCULATOR"), "I could not open Calculator."); return; }
        if (containsAny(q, "clock", "alarm", "घड़ी", "अलार्म")) { intent(new Intent("android.intent.action.SHOW_ALARMS"), "I could not open Clock."); return; }
        if (containsAny(q, "messages", "sms", "message", "मैसेज", "संदेश")) { intent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), "I could not open Messages."); return; }
        if (containsAny(q, "call", "फोन लगाओ", "कॉल", "फोन करो")) { say("Opening phone dialer. Please select a contact and confirm."); intent(new Intent(Intent.ACTION_DIAL), "I could not open the dialer."); return; }
        if (containsAny(q, "time", "समय", "कितने बजे")) { say("The time is " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date())); return; }
        if (containsAny(q, "stop listening", "goodbye", "सुनना बंद", "बंद हो जाओ")) { say("Okay, stopping listening."); h.postDelayed(this::stopSelf, 2200); return; }
        if (containsAny(q, "open", "खोलो", "खोल दो", "चालू करो")) {
            say("I did not understand which app to open. Please say the app name.");
            return;
        }
        say("I can open YouTube, Google, WhatsApp, Camera, Settings, Maps, Calculator, Clock, Messages, or the phone dialer. You can ask in English or Hindi.");
    }

    private boolean containsAny(String q, String... words) {
        for (String w : words) if (q.contains(w)) return true;
        return false;
    }
    private void url(String u) { say("Opening it now."); intent(new Intent(Intent.ACTION_VIEW, Uri.parse(u)), "Could not open that link."); }
    private void pkg(String p, String f) { Intent i = getPackageManager().getLaunchIntentForPackage(p); if (i == null) say(f); else intent(i, f); }
    private void intent(Intent i, String f) { try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); } catch (Exception e) { say(f); } }

    private void say(String m) {
        if (tts == null) return;
        speaking = true;
        try { if (sr != null) sr.cancel(); } catch (Exception ignored) {}
        try { tts.speak(m, TextToSpeech.QUEUE_FLUSH, null, "friday" + System.currentTimeMillis()); }
        catch (Exception ignored) {}
        h.postDelayed(() -> { speaking = false; listen(); }, Math.max(2200, m.length() * 75L));
    }

    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (sr != null) { sr.cancel(); sr.destroy(); }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        stopForeground(true);
        super.onDestroy();
    }
}

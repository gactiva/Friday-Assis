package com.friday.assistant;
import android.Manifest; import android.app.Activity; import android.content.Intent; import android.content.pm.PackageManager; import android.os.Bundle; import android.view.Gravity; import android.widget.*;
public class MainActivity extends Activity {
 private static final int REQ=101; private TextView status;
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,40,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL);
 TextView title=new TextView(this); title.setText("FRIDAY"); title.setTextSize(32); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
 TextView help=new TextView(this); help.setText("Background wake-word prototype\n\nTap Start, keep the notification visible, then say “Friday”. Try “Friday, open YouTube”."); help.setTextSize(17); help.setPadding(0,24,0,24); root.addView(help);
 status=new TextView(this); status.setText("Status: stopped"); root.addView(status);
 Button start=new Button(this); start.setText("START FRIDAY LISTENING"); start.setOnClickListener(v->startFriday()); root.addView(start,new LinearLayout.LayoutParams(-1,-2));
 Button stop=new Button(this); stop.setText("STOP LISTENING"); stop.setOnClickListener(v->{stopService(new Intent(this,FridayListeningService.class));status.setText("Status: stopped");}); root.addView(stop,new LinearLayout.LayoutParams(-1,-2)); setContentView(root); }
 private void startFriday(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ);return;} startForegroundService(new Intent(this,FridayListeningService.class));status.setText("Listening; notification should appear.");}
 public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startFriday();else if(r==REQ)status.setText("Microphone permission required.");}
}

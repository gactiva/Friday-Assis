package com.friday.assistant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.*;
import java.text.SimpleDateFormat;

public class FridayListeningService extends Service implements RecognitionListener {
    private static final String CH = "friday_listening";
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean running = false, speaking = false, nextHindi = false;
    private Locale lastSpeechLocale = new Locale("en", "IN");

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Friday listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while Friday listens");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                chooseVoice(new Locale("en", "IN"));
            }
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(this);
        }
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        running = true;
        Intent open = new Intent(this, MainActivity.class);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pf |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, pf);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        Notification n = nb.setContentTitle("Friday / JARVIS is listening")
                .setContentText("Say Friday or Jarvis, then your command")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
        startForeground(4401, n);
        listen();
        return START_STICKY;
    }

    private void listen() {
        if (!running || speaking || sr == null) return;
        h.postDelayed(() -> {
            if (!running || speaking || sr == null) return;
            try {
                Locale locale = nextHindi ? new Locale("hi", "IN") : new Locale("en", "IN");
                nextHindi = !nextHindi;
                lastSpeechLocale = locale;
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag());
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale.toLanguageTag());
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                sr.startListening(i);
            } catch (Exception e) { restart(1400); }
        }, 500);
    }

    private void restart(long delay) { if (running) h.postDelayed(this::listen, delay); }

    @Override public void onResults(Bundle b) {
        ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (results != null) {
            for (String result : results) {
                if (result != null && hasWakeWord(result.toLowerCase(Locale.ROOT))) {
                    handle(result);
                    break;
                }
            }
        }
        restart(900);
    }

    private boolean hasWakeWord(String q) {
        return q.matches("(?s).*(\\bfriday\\b|\\bfridai\\b|\\bfreddie\\b|\\bjarvis\\b|जार्विस|जारविस|फ्राइडे|फ्राइडे).*");
    }

    private void handle(String text) {
        String q = text.toLowerCase(Locale.ROOT).trim();
        String c = q.replaceAll("(\\bfriday\\b|\\bfridai\\b|\\bfreddie\\b|\\bjarvis\\b|जार्विस|जारविस|फ्राइडे)", " ")
                    .replaceAll("^[ ,.!?]+", "").trim();
        if (c.isEmpty()) { say("Yes? What can I do for you?", false); return; }
        command(c);
    }

    private boolean hasAny(String q, String... words) {
        for (String word : words) if (q.contains(word)) return true;
        return false;
    }

    private void command(String q) {
        boolean hi = hasAny(q, "खोल", "खोलो", "खोलना", "बताओ", "समय", "बंद", "चालू", "यूट्यूब", "गूगल", "कैमरा", "सेटिंग", "व्हाट्सएप", "समझाओ", "जार्विस");
        if (hasAny(q, "youtube", "यूट्यूब")) url("https://www.youtube.com", hi ? "यूट्यूब खोल रहा हूँ।" : "Opening YouTube.");
        else if (hasAny(q, "google", "search", "browser", "chrome", "गूगल", "सर्च", "ब्राउज़र", "क्रोम")) url("https://www.google.com", hi ? "गूगल खोल रहा हूँ।" : "Opening Google.");
        else if (hasAny(q, "whatsapp", "व्हाट्सएप", "व्हाट्स ऐप")) pkg("com.whatsapp", hi ? "व्हाट्सएप नहीं मिला।" : "I could not find WhatsApp.");
        else if (hasAny(q, "camera", "photo", "कैमरा", "फोटो")) intent(new Intent("android.media.action.IMAGE_CAPTURE"), hi ? "कैमरा खोल नहीं पाया।" : "I could not open Camera.", hi ? "कैमरा खोल रहा हूँ।" : "Opening Camera.");
        else if (hasAny(q, "settings", "सेटिंग", "सेटिंग्स")) intent(new Intent(android.provider.Settings.ACTION_SETTINGS), hi ? "सेटिंग्स नहीं खुलीं।" : "I could not open Settings.", hi ? "सेटिंग्स खोल रहा हूँ।" : "Opening Settings.");
        else if (hasAny(q, "maps", "navigation", "मैप", "नक्शा", "रास्ता")) url("https://maps.google.com", hi ? "मैप्स खोल रहा हूँ।" : "Opening Maps.");
        else if (hasAny(q, "calculator", "कैलकुलेटर", "गणना")) intent(new Intent("android.intent.action.MAIN").addCategory("android.intent.category.APP_CALCULATOR"), hi ? "कैलकुलेटर नहीं खुला।" : "I could not open Calculator.", hi ? "कैलकुलेटर खोल रहा हूँ।" : "Opening Calculator.");
        else if (hasAny(q, "clock", "alarm", "घड़ी", "अलार्म")) intent(new Intent("android.intent.action.SHOW_ALARMS"), hi ? "घड़ी नहीं खुली।" : "I could not open Clock.", hi ? "घड़ी खोल रहा हूँ।" : "Opening Clock.");
        else if (hasAny(q, "messages", "sms", "message", "मैसेज", "संदेश")) intent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), hi ? "मैसेज ऐप नहीं खुला।" : "I could not open Messages.", hi ? "मैसेज खोल रहा हूँ।" : "Opening Messages.");
        else if (hasAny(q, "call", "phone", "कॉल", "फोन", "फ़ोन")) { say(hi ? "फोन डायलर खोल रहा हूँ। कृपया संपर्क चुनकर कॉल की पुष्टि करें।" : "Opening phone dialer. Please select a contact and confirm.", hi); intent(new Intent(Intent.ACTION_DIAL), hi ? "डायलर नहीं खुला।" : "I could not open the dialer.", null); }
        else if (hasAny(q, "time", "समय", "बजे", "टाइम")) say(hi ? "अभी समय है " + new SimpleDateFormat("h:mm a", new Locale("hi", "IN")).format(new Date()) : "The time is " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date()), hi);
        else if (hasAny(q, "stop listening", "goodbye", "सुनना बंद", "बंद हो जाओ", "रुक जाओ")) { say(hi ? "ठीक है, सुनना बंद कर रहा हूँ।" : "Okay, stopping listening.", hi); h.postDelayed(this::stopSelf, 2500); }
        else say(hi ? "मैं यूट्यूब, गूगल, व्हाट्सएप, कैमरा, सेटिंग्स, मैप्स, कैलकुलेटर, घड़ी, मैसेज और फोन खोल सकता हूँ।" : "I can open YouTube, Google, WhatsApp, Camera, Settings, Maps, Calculator, Clock, Messages, or the phone dialer.", hi);
    }

    private void chooseVoice(Locale locale) {
        if (tts == null) return;
        int result = tts.setLanguage(locale);
        tts.setPitch(0.82f);
        if (Build.VERSION.SDK_INT >= 21 && result >= TextToSpeech.LANG_AVAILABLE) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        String name = v.getName().toLowerCase(Locale.ROOT);
                        if (v.getLocale().getLanguage().equals(locale.getLanguage()) &&
                                (name.contains("male") || name.contains("man") || name.contains("masculine"))) {
                            tts.setVoice(v);
                            break;
                        }
                    }
                }
            } catch (Exception ignored) { }
        }
    }

    private void say(String message, boolean hindi) {
        if (tts == null) return;
        speaking = true;
        chooseVoice(hindi ? new Locale("hi", "IN") : new Locale("en", "IN"));
        try { if (sr != null) sr.cancel(); } catch (Exception ignored) { }
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "friday" + System.currentTimeMillis());
        h.postDelayed(() -> { speaking = false; listen(); }, Math.max(2200, message.length() * 85L));
    }

    private void url(String u, String spoken) {
        say(spoken, spoken.matches(".*[\\u0900-\\u097F].*"));
        intent(new Intent(Intent.ACTION_VIEW, Uri.parse(u)), "Could not open that link.", null);
    }
    private void pkg(String p, String failure) {
        Intent i = getPackageManager().getLaunchIntentForPackage(p);
        if (i == null) say(failure, failure.matches(".*[\\u0900-\\u097F].*"));
        else intent(i, failure, null);
    }
    private void intent(Intent i, String failure, String spoken) {
        try {
            if (spoken != null) say(spoken, spoken.matches(".*[\\u0900-\\u097F].*"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) { say(failure, failure.matches(".*[\\u0900-\\u097F].*")); }
    }

    @Override public void onError(int e) { restart(1300); }
    @Override public void onReadyForSpeech(Bundle b) { }
    @Override public void onBeginningOfSpeech() { }
    @Override public void onRmsChanged(float r) { }
    @Override public void onBufferReceived(byte[] b) { }
    @Override public void onEndOfSpeech() { }
    @Override public void onEvent(int e, Bundle b) { }
    @Override public void onPartialResults(Bundle b) { }
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (sr != null) { sr.cancel(); sr.destroy(); }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        stopForeground(true);
        super.onDestroy();
    }
}

Friday / JARVIS bilingual background-listening prototype (Version 3).

Features:
- Wake words: Friday and Jarvis, with some common speech-recognition variants.
- Alternates speech recognition sessions between English (India) and Hindi (India). This is not simultaneous bilingual recognition; the phone's speech service must support both languages.
- Basic English, Hindi and Hinglish app-opening/time commands.
- Requests an installed male-labelled TTS voice when available and uses a lower pitch as a fallback. Android TTS voices do not always expose reliable gender labels, so a male voice is not guaranteed.
- Visible foreground microphone service; keep its notification visible.

Build:
Upload this ZIP to your GitHub repository and set .github/workflows/build.yml to extract FridayAssistantNext7.zip, then run Actions. The source has not been compiled or tested on a device in this environment. Keep the previous working APK and ZIP as backups.

Limitations:
Android SpeechRecognizer may require internet and depends on the installed speech provider. Alternating languages can miss commands spoken while the other language is selected. This is a prototype, not a guaranteed always-on/offline assistant. Stop listening with "Friday stop listening" or "Jarvis सुनना बंद".

package com.friday.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int REQ = 101;
    private TextView status;
    private RadioGroup personaGroup, languageGroup;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("FRIDAY / JARVIS");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = new TextView(this);
        intro.setText("Choose assistant personality and command language before starting.");
        intro.setTextSize(16);
        intro.setPadding(0, 18, 0, 12);
        root.addView(intro);

        TextView pLabel = new TextView(this);
        pLabel.setText("Assistant voice");
        pLabel.setTextSize(18);
        root.addView(pLabel);

        personaGroup = new RadioGroup(this);
        personaGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton friday = new RadioButton(this);
        friday.setId(1);
        friday.setText("Friday — default voice");
        friday.setChecked(true);
        personaGroup.addView(friday);
        RadioButton jarvis = new RadioButton(this);
        jarvis.setId(2);
        jarvis.setText("Jarvis — request male voice");
        personaGroup.addView(jarvis);
        root.addView(personaGroup);

        TextView lLabel = new TextView(this);
        lLabel.setText("Command language (choose one)");
        lLabel.setTextSize(18);
        lLabel.setPadding(0, 14, 0, 0);
        root.addView(lLabel);

        languageGroup = new RadioGroup(this);
        languageGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton english = new RadioButton(this);
        english.setId(11);
        english.setText("English — reply in English");
        english.setChecked(true);
        languageGroup.addView(english);
        RadioButton hindi = new RadioButton(this);
        hindi.setId(12);
        hindi.setText("Hindi — जवाब हिंदी में");
        languageGroup.addView(hindi);
        root.addView(languageGroup);

        TextView help = new TextView(this);
        help.setText("Examples:\nJarvis, open YouTube, over.\nFriday, time please, over.\nHindi mode: Jarvis, YouTube kholo, over.\n\nSay “Friday” or “Jarvis” to start command capture, then say the command and finish with “over”. No “yes boss” prompt is played. Ambient speech is ignored until the wake word. Background listening can still hear environmental sound; avoid private conversations near the phone.");
        help.setTextSize(14);
        help.setPadding(0, 16, 0, 16);
        root.addView(help);

        status = new TextView(this);
        status.setText("Status: stopped");
        root.addView(status);

        Button start = new Button(this);
        start.setText("START LISTENING");
        start.setOnClickListener(v -> startAssistant());
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));

        Button stop = new Button(this);
        stop.setText("STOP LISTENING");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, FridayListeningService.class));
            status.setText("Status: stopped");
        });
        root.addView(stop, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void startAssistant() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ);
            return;
        }
        startChosenService();
    }

    private void startChosenService() {
        Intent i = new Intent(this, FridayListeningService.class);
        i.putExtra("persona", personaGroup.getCheckedRadioButtonId() == 2 ? "jarvis" : "friday");
        i.putExtra("language", languageGroup.getCheckedRadioButtonId() == 12 ? "hi-IN" : "en-IN");
        startForegroundService(i);
        String who = personaGroup.getCheckedRadioButtonId() == 2 ? "Jarvis" : "Friday";
        String lang = languageGroup.getCheckedRadioButtonId() == 12 ? "Hindi" : "English";
        status.setText("Starting " + who + " in " + lang + " mode.");
    }

    public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startChosenService();
        else if (r == REQ) status.setText("Microphone permission required.");
    }
}

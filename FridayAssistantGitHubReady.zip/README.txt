FRIDAY ASSISTANT — GitHub Actions build starter

This ZIP contains source code, not a prebuilt APK.
Upload the CONTENTS of this extracted folder to your empty GitHub repository,
keeping the folder structure. On a Chromebook, extract the ZIP in Files, open
the extracted folder, select all its contents (Ctrl+A), then drag them to the
GitHub Upload files page. Commit the upload.

After committing, open Actions. The workflow "Build Friday Android APK" should
run automatically. When complete, open the run and download artifact
"Friday-debug-apk". Extract that downloaded ZIP and install app-debug.apk.

This starter has push-to-talk speech recognition and basic phone commands only.
It does not yet include a hands-free wake word or AI API integration. Do not put
API keys in a public repository.

package com.friday.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 100;
    private static final int REQ_AUDIO = 101;
    private TextView transcript;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en", "IN"));
        });
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 32, 24, 24);
        TextView title = new TextView(this);
        title.setText("FRIDAY");
        title.setTextSize(32);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Your voice assistant starter");
        subtitle.setTextSize(16);
        root.addView(subtitle);
        transcript = new TextView(this);
        transcript.setText("Tap the button and speak. Try: time, open YouTube, open settings.");
        transcript.setTextSize(18);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(transcript);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button speak = new Button(this);
        speak.setText("TALK TO FRIDAY");
        speak.setOnClickListener(v -> startListening());
        root.addView(speak);
        setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Friday");
            startActivityForResult(i, REQ_SPEECH);
        } catch (Exception e) { say("Speech recognition is not available on this device."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) handleCommand(results.get(0));
        }
    }

    private void handleCommand(String raw) {
        String q = raw.toLowerCase(Locale.ROOT);
        transcript.setText("You: " + raw);
        if (q.contains("time") || q.contains("समय") || q.contains("टाइम")) {
            say("The time is " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date()));
        } else if (q.contains("youtube") || q.contains("यूट्यूब")) {
            openUrl("https://www.youtube.com");
        } else if (q.contains("chrome") || q.contains("browser") || q.contains("ब्राउज़र")) {
            openUrl("https://www.google.com");
        } else if (q.contains("whatsapp") || q.contains("व्हाट्सएप")) {
            launchPackage("com.whatsapp", "I could not find WhatsApp.");
        } else if (q.contains("camera") || q.contains("कैमरा")) {
            launchIntent(new Intent("android.media.action.IMAGE_CAPTURE"), "I could not open the camera.");
        } else if (q.contains("settings") || q.contains("सेटिंग")) {
            launchIntent(new Intent(android.provider.Settings.ACTION_SETTINGS), "I could not open Settings.");
        } else if (q.contains("hello") || q.contains("नमस्ते") || q.contains("हेलो")) {
            say("Hello! I am Friday. How can I help you?");
        } else {
            say("I heard: " + raw + ". I am a starter version, so I cannot answer general AI questions yet.");
        }
    }
    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))); }
        catch (Exception e) { say("I could not open that link."); }
    }
    private void launchPackage(String pkg, String fail) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) say(fail); else startActivity(i);
    }
    private void launchIntent(Intent i, String fail) {
        try { startActivity(i); } catch (Exception e) { say(fail); }
    }
    private void say(String message) {
        transcript.setText("Friday: " + message);
        if (tts != null) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "friday");
    }
    @Override public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}

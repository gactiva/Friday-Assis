package com.friday.assistant;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.animation.ValueAnimator;
import android.animation.ArgbEvaluator;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

public class AssistantOverlayService extends Service {
    private WindowManager wm;
    private View bar;
    private ValueAnimator anim;
    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        bar=new View(this);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{Color.CYAN, Color.MAGENTA, Color.YELLOW, Color.GREEN, Color.CYAN});
        bg.setCornerRadius(30f);
        bar.setBackground(bg);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, 7, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP;
        try { wm.addView(bar,p); } catch(Exception e) { stopSelf(); return; }
        anim=ValueAnimator.ofFloat(0f,1f); anim.setDuration(900); anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.addUpdateListener(a->{float v=(float)a.getAnimatedValue(); bar.setAlpha(0.35f+0.65f*(float)Math.abs(Math.sin(v*Math.PI*2)));});
        anim.start();
        bar.postDelayed(()->stopSelf(),5000);
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_NOT_STICKY;}
    @Override public void onDestroy(){if(anim!=null)anim.cancel(); if(bar!=null&&wm!=null)try{wm.removeView(bar);}catch(Exception ignored){} super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}

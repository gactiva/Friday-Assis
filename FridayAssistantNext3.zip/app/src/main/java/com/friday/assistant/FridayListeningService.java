package com.friday.assistant;
import android.app.*; import android.content.*; import android.os.*; import android.provider.Settings; import android.net.Uri; import android.speech.tts.TextToSpeech; import java.util.*; import java.text.SimpleDateFormat;
import org.vosk.Model; import org.vosk.Recognizer; import org.vosk.android.RecognitionListener; import org.vosk.android.SpeechService; import org.vosk.android.StorageService;
public class FridayListeningService extends Service implements RecognitionListener {
 private static final String CH="friday_listening"; private TextToSpeech tts; private Handler h=new Handler(Looper.getMainLooper()); private boolean running=false,speaking=false,ready=false; private PowerManager.WakeLock wakeLock; private Model model; private SpeechService speech;
 public void onCreate(){super.onCreate(); if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"Friday listening",NotificationManager.IMPORTANCE_LOW);c.setDescription("Visible notification while Friday listens");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}
 tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("en","IN"));});
 PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Friday:Listening");}
 public int onStartCommand(Intent in,int flags,int id){running=true;try{if(wakeLock!=null&&!wakeLock.isHeld())wakeLock.acquire(10*60*60*1000L);}catch(Exception ignored){}
 Intent open=new Intent(this,MainActivity.class);int pf=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=23)pf|=PendingIntent.FLAG_IMMUTABLE;PendingIntent pi=PendingIntent.getActivity(this,0,open,pf);
 Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);startForeground(4401,nb.setContentTitle("Friday is listening").setContentText("Offline English speech model").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build());
 StorageService.unpack(this,"model","model",(m)->{model=m;try{Recognizer r=new Recognizer(model,16000.0f);speech=new SpeechService(r,16000.0f);speech.startListening(this);ready=true;}catch(Exception e){say("Offline speech engine could not start. Please check model assets.");}},(e)->say("Offline model is missing. Rebuild the app with the model download step."));
 return START_STICKY;}
 @Override public void onPartialResult(String h){} @Override public void onResult(String r){handleJson(r,false);} @Override public void onFinalResult(String r){handleJson(r,true);if(running)h.postDelayed(()->{try{if(speech!=null)speech.startListening(this);}catch(Exception ignored){}},500);} @Override public void onError(Exception e){if(running)h.postDelayed(()->{try{if(speech!=null)speech.startListening(this);}catch(Exception ignored){}},1200);} @Override public void onTimeout(){if(running)try{speech.startListening(this);}catch(Exception ignored){}}
 private void handleJson(String json,boolean fin){try{org.json.JSONObject o=new org.json.JSONObject(json);String text=o.optString("text","").toLowerCase(Locale.ROOT).trim();if(text.isEmpty())return;
 if(text.matches(".*\\b(friday|jarvis)\\b.*")){String q=text.replaceFirst(".*\\b(friday|jarvis)\\b","").trim();if(!q.isEmpty())command(q);else say("Yes?");}
 else if(FridayAccessibilityService.recording && text.startsWith("save command")){String name=text.replace("save command","").trim();if(name.isEmpty())name="my command";FridayAccessibilityService.macroName=name;FridayAccessibilityService.stopAndSave(this);say("Saved command "+name);}
 }catch(Exception ignored){}}
 private void command(String q){wakeScreen();try{if(Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(this))startService(new Intent(this,AssistantOverlayService.class));}catch(Exception ignored){}
 if(q.startsWith("write ")||q.startsWith("type ")){String body=q.substring(q.indexOf(' ')+1).trim();boolean ok=FridayAccessibilityService.typeIntoFocused(body);say(ok?"Typed your text.":"I couldn't type. Enable Friday Accessibility and focus a text field first.");return;}
 if(q.startsWith("learn command")||q.startsWith("record command")){String name=q.replaceFirst("^(learn|record) command","").trim();if(name.isEmpty())name="my command";FridayAccessibilityService.startRecording(name);say("Recording clicks. Perform the steps, then say Friday save command "+name);return;}
 if(q.startsWith("save command")){String name=q.replaceFirst("^save command","").trim();if(name.isEmpty())name="my command";FridayAccessibilityService.macroName=name;FridayAccessibilityService.stopAndSave(this);say("Saved command "+name);return;}
 if(q.startsWith("run command")||q.startsWith("open internet")){String name=q.startsWith("open internet")?"open internet":q.replaceFirst("^run command","").trim();if(FridayAccessibilityService.replay(this,name))say("Running "+name);else if(q.contains("internet"))url("https://www.google.com");else say("I couldn't find that saved command.");return;}
 if(q.startsWith("open "))q=q.substring(5).trim();
 if(q.contains("youtube"))url("https://www.youtube.com");
 else if(q.contains("google")||q.contains("search")||q.contains("browser")||q.equals("internet")||q.contains("chrome"))url("https://www.google.com");
 else if(q.contains("whatsapp"))pkg("com.whatsapp","I could not find WhatsApp.");
 else if(q.contains("camera")||q.contains("photo"))intent(new Intent("android.media.action.IMAGE_CAPTURE"),"I could not open Camera.");
 else if(q.contains("settings"))intent(new Intent(android.provider.Settings.ACTION_SETTINGS),"I could not open Settings.");
 else if(q.contains("maps")||q.contains("navigation"))url("https://maps.google.com");
 else if(q.contains("calculator"))intent(new Intent("android.intent.action.MAIN").addCategory("android.intent.category.APP_CALCULATOR"),"I could not open Calculator.");
 else if(q.contains("clock")||q.contains("alarm"))intent(new Intent("android.intent.action.SHOW_ALARMS"),"I could not open Clock.");
 else if(q.contains("messages")||q.contains("sms"))intent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),"I could not open Messages.");
 else if(q.contains("call")){say("Opening phone dialer. Please select a contact and confirm.");intent(new Intent(Intent.ACTION_DIAL),"I could not open the dialer.");}
 else if(q.contains("time"))say("The time is "+new SimpleDateFormat("h:mm a",Locale.getDefault()).format(new Date()));
 else if(q.contains("stop listening")||q.contains("goodbye")){say("Okay, stopping listening.");h.postDelayed(this::stopSelf,2200);}
 else say("Try open WhatsApp, open Internet, write followed by text, learn command followed by a name, or run command followed by a name.");}
 private void wakeScreen(){try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);PowerManager.WakeLock wl=pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,"Friday:WakeDisplay");wl.acquire(3000);h.postDelayed(()->{try{if(wl.isHeld())wl.release();}catch(Exception ignored){}},3200);}catch(Exception ignored){}}
 private void url(String u){say("Opening it now.");intent(new Intent(Intent.ACTION_VIEW,Uri.parse(u)),"Could not open that link.");}
 private void pkg(String p,String f){Intent i=getPackageManager().getLaunchIntentForPackage(p);if(i==null)say(f);else intent(i,f);}
 private void intent(Intent i,String f){try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){say(f);}}
 private void say(String m){if(tts!=null)tts.speak(m,TextToSpeech.QUEUE_FLUSH,null,"friday"+System.currentTimeMillis());}
 public IBinder onBind(Intent i){return null;} public void onDestroy(){running=false;if(speech!=null)speech.stop();if(model!=null)model.close();if(tts!=null){tts.stop();tts.shutdown();}if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}stopForeground(true);super.onDestroy();}
}

package com.friday.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Build;
import java.util.*;

public class FridayAccessibilityService extends AccessibilityService {
 static FridayAccessibilityService instance;
 static boolean recording=false;
 static String macroName="my command";
 static ArrayList<String> recorded=new ArrayList<>();
 @Override public void onServiceConnected(){instance=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){
   if(!recording || e.getEventType()!=AccessibilityEvent.TYPE_VIEW_CLICKED)return;
   AccessibilityNodeInfo n=e.getSource(); if(n==null)return;
   CharSequence text=n.getText(); String label=text==null?"":text.toString();
   String id=""; try{id=n.getViewIdResourceName();}catch(Exception ignored){}
   if(!label.isEmpty() || !id.isEmpty()) {
     String action=(id==null?"":id)+"|"+label;
     if(recorded.size()<40) recorded.add(action);
   }
   n.recycle();
 }
 @Override public void onInterrupt(){}
 public static void startRecording(String name){recording=true;macroName=name;recorded.clear();}
 public static void stopAndSave(android.content.Context c){
   recording=false; StringBuilder b=new StringBuilder();
   for(String s:recorded){if(b.length()>0)b.append("\n");b.append(s);}
   c.getSharedPreferences("friday_macros",0).edit().putString(macroName,b.toString()).apply();
 }
 public static boolean replay(android.content.Context c,String name){
   if(instance==null)return false;
   String data=c.getSharedPreferences("friday_macros",0).getString(name,null); if(data==null)return false;
   String[] actions=data.split("\n");
   instance.replayAt(actions,0);return true;
 }
 private void replayAt(String[] actions,int idx){
   if(idx>=actions.length)return;
   String[] pair=actions[idx].split("\\|",2);String id=pair.length>0?pair[0]:"";String label=pair.length>1?pair[1]:"";
   AccessibilityNodeInfo root=getRootInActiveWindow(); AccessibilityNodeInfo found=null;
   if(root!=null&&!id.isEmpty()) {try{List<AccessibilityNodeInfo> ns=root.findAccessibilityNodeInfosByViewId(id);if(ns!=null&&!ns.isEmpty())found=ns.get(0);}catch(Exception ignored){}}
   if(found==null&&root!=null&&!label.isEmpty()){List<AccessibilityNodeInfo> ns=root.findAccessibilityNodeInfosByText(label);if(ns!=null&&!ns.isEmpty())found=ns.get(0);}
   if(found!=null){if(found.isClickable())found.performAction(AccessibilityNodeInfo.ACTION_CLICK);else {AccessibilityNodeInfo p=found.getParent();while(p!=null&&!p.isClickable()){AccessibilityNodeInfo next=p.getParent();p.recycle();p=next;}if(p!=null){p.performAction(AccessibilityNodeInfo.ACTION_CLICK);p.recycle();}}found.recycle();}
   if(root!=null)root.recycle();
   new android.os.Handler(getMainLooper()).postDelayed(()->replayAt(actions,idx+1),700);
 }
 public static boolean typeIntoFocused(String text){
   if(instance==null)return false; AccessibilityNodeInfo root=instance.getRootInActiveWindow(); if(root==null)return false;
   AccessibilityNodeInfo focus=root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);boolean ok=false;
   if(focus!=null){Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);ok=focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);focus.recycle();}
   root.recycle();return ok;
 }
}

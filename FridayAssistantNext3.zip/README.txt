FRIDAY ASSISTANT V3 — prototype
================================
Features added together:
1) Vosk offline English speech recognition. GitHub Actions downloads the Vosk small English model during the build and packages it into the APK. Internet is required to BUILD; the app's Vosk recognition is intended to run offline after install.
3) Voice typing: say "Friday, write <text>" with a text field focused. Requires enabling Friday Accessibility service. It uses Android ACTION_SET_TEXT on the focused accessible field; not all apps/fields permit it.
4) Basic teach/replay macros: say "Friday, learn command <name>", then tap accessible UI controls in the target app. Say "Friday, save command <name>". Later say "Friday, run command <name>". Stored macros are local. The prototype records accessible click events only; it does not record arbitrary swipe gestures or guarantee robust replay across changed screens.
Also retains best-effort wake screen and colorful top line from the previous prototype.

IMPORTANT:
- This is uncompiled and untested source; do not assume it will build or work until GitHub Actions is green and the APK is tested.
- Workflow expects the uploaded ZIP to be named FridayAssistantNext3.zip at repository root. Update your existing workflow to extract that exact name, or use this ZIP's .github/workflows/build.yml.
- Keep the previous APK and source ZIP as backups.
- The offline model is downloaded by GitHub Actions from alphacephei.com; first build requires internet. The resulting app's Vosk speech recognition should not require internet, but Android Text-to-Speech may need an installed offline English voice for spoken responses.
- Macro recording uses Accessibility and requires explicit user enablement. No hidden recording. It stores tap descriptions locally only.

Friday/Jarvis Assistant - Next10 (based on the user's V9 source)

Changes from V9:
- Saying only "Friday" or "Jarvis" is silent. It will not reply "Yes?", "Yes, sir?", or a Hindi acknowledgement. Say the wake word plus a command.
- Fixes a potential repeated listening/restart loop by scheduling only one pending listening restart at a time.
- Keeps existing Friday/Jarvis and English/Hindi selections and existing commands.
- No offline model is added in this version.

Build notes:
- This ZIP includes the GitHub Actions workflow. Its extraction step expects this ZIP to be uploaded to the repository root as FridayAssistantNext10.zip.
- If your repository already has a working workflow that extracts a different ZIP filename, keep your current workflow and change only its unzip filename to FridayAssistantNext10.zip, or upload the project contents directly to the repository root.
- The source has not been compiled or tested on a physical phone here. Keep your V9 ZIP as backup and test this as a separate version.

Usage:
- Say "Friday, open YouTube, over" or "Jarvis, what time is it, over" depending on selected persona.
- The assistant no longer gives a spoken response to the wake word alone.


Next12 changes: based on V9 source (not offline/Vosk). Friday/Jarvis acknowledges a wake word with “Yes, boss?” (Hindi mode says “जी, बताइए।”); you do not need to say “boss” yourself. It briefly attempts to suppress the Android speech-recognition startup beep by muting the system stream only during recognizer startup, then restoring its previous volume. Some phone speech-recognition providers may ignore this; test on device.

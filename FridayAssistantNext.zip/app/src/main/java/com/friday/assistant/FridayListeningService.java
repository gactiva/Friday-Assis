package com.friday.assistant;
import android.app.*; import android.content.*; import android.os.*; import android.provider.Settings; import android.speech.*; import android.net.Uri; import android.speech.tts.TextToSpeech; import java.util.*; import java.text.SimpleDateFormat;
public class FridayListeningService extends Service implements RecognitionListener {
 private static final String CH="friday_listening"; private SpeechRecognizer sr; private TextToSpeech tts; private Handler h=new Handler(Looper.getMainLooper()); private boolean running=false,speaking=false; private PowerManager.WakeLock wakeLock;
 public void onCreate(){super.onCreate(); if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"Friday listening",NotificationManager.IMPORTANCE_LOW);c.setDescription("Visible notification while Friday listens");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}
 tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(new Locale("en","IN"));});
 PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
 wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Friday:Listening"); 
 sr=SpeechRecognizer.createSpeechRecognizer(this);sr.setRecognitionListener(this);}
 public int onStartCommand(Intent in,int flags,int id){running=true; try{if(wakeLock!=null&&!wakeLock.isHeld())wakeLock.acquire(10*60*60*1000L);}catch(Exception ignored){} Intent open=new Intent(this,MainActivity.class);int pf=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=23)pf|=PendingIntent.FLAG_IMMUTABLE;PendingIntent pi=PendingIntent.getActivity(this,0,open,pf);
 Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);Notification n=nb.setContentTitle("Friday is listening").setContentText("Say Friday to activate a command").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();startForeground(4401,n);listen();return START_STICKY;}
 private void listen(){if(!running||speaking||sr==null)return;h.postDelayed(()->{if(!running||speaking)return;try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"en-IN");i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);sr.startListening(i);}catch(Exception e){restart(1200);}},500);}
 private void restart(long d){if(running)h.postDelayed(this::listen,d);}
 public void onResults(Bundle b){ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty())handle(a.get(0));restart(800);}
 public void onError(int e){restart(1200);} public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){} public void onEvent(int e,Bundle b){} public void onPartialResults(Bundle b){}
 private void handle(String text){String q=text.toLowerCase(Locale.ROOT).trim();if(!q.matches(".*\\b(friday|fridai|freddie|jarvis|jervis)\\b.*"))return;String c=q.replaceAll(".*\\b(friday|fridai|freddie|jarvis|jervis)\\b","").replaceAll("^[ ,.!?]+","").trim();if(c.isEmpty()){say("Yes? What can I do for you?");return;}command(c);}
 private void command(String q){
 // Wake the display on supported Android versions; this does not unlock the device.
 wakeScreen();
 // Show a short colorful line when the overlay permission has been granted.
 try { if(Build.VERSION.SDK_INT<23 || Settings.canDrawOverlays(this))
   startService(new Intent(this,AssistantOverlayService.class)); } catch(Exception ignored) {}
 if(q.startsWith("write ") || q.startsWith("type ")) { say("Text to type: "+q.substring(q.indexOf(' ')+1)+". Automatic typing into other apps is not enabled in this prototype."); return; }
 if(q.contains("save command") || q.contains("learn command")) { say("Custom workflow recording is not included in this prototype yet."); return; }

 if(q.contains("youtube"))url("https://www.youtube.com");
 else if(q.contains("google")||q.contains("search")||q.contains("browser")||q.contains("chrome"))url("https://www.google.com");
 else if(q.contains("whatsapp"))pkg("com.whatsapp","I could not find WhatsApp.");
 else if(q.contains("camera")||q.contains("photo"))intent(new Intent("android.media.action.IMAGE_CAPTURE"),"I could not open Camera.");
 else if(q.contains("settings"))intent(new Intent(android.provider.Settings.ACTION_SETTINGS),"I could not open Settings.");
 else if(q.contains("maps")||q.contains("navigation"))url("https://maps.google.com");
 else if(q.contains("calculator"))intent(new Intent("android.intent.action.MAIN").addCategory("android.intent.category.APP_CALCULATOR"),"I could not open Calculator.");
 else if(q.contains("clock")||q.contains("alarm"))intent(new Intent("android.intent.action.SHOW_ALARMS"),"I could not open Clock.");
 else if(q.contains("messages")||q.contains("sms"))intent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),"I could not open Messages.");
 else if(q.contains("call")){say("Opening phone dialer. Please select a contact and confirm.");intent(new Intent(Intent.ACTION_DIAL),"I could not open the dialer.");}
 else if(q.contains("time"))say("The time is "+new SimpleDateFormat("h:mm a",Locale.getDefault()).format(new Date()));
 else if(q.contains("stop listening")||q.contains("goodbye")){say("Okay, stopping listening.");h.postDelayed(this::stopSelf,2200);}
 else say("I can open YouTube, Google, WhatsApp, Camera, Settings, Maps, Calculator, Clock, Messages, or the phone dialer.");}
 private void wakeScreen(){
   try {
     PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
     if(Build.VERSION.SDK_INT>=27) {
       PowerManager.WakeLock wl=pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,"Friday:WakeDisplay");
       wl.acquire(3000);
       h.postDelayed(()->{try{if(wl.isHeld())wl.release();}catch(Exception ignored){}},3200);
     } else {
       PowerManager.WakeLock wl=pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,"Friday:WakeDisplay");
       wl.acquire(3000);
       h.postDelayed(()->{try{if(wl.isHeld())wl.release();}catch(Exception ignored){}},3200);
     }
   } catch(Exception ignored) {}
 }
 private void url(String u){say("Opening it now.");intent(new Intent(Intent.ACTION_VIEW,Uri.parse(u)),"Could not open that link.");}
 private void pkg(String p,String f){Intent i=getPackageManager().getLaunchIntentForPackage(p);if(i==null)say(f);else intent(i,f);}
 private void intent(Intent i,String f){try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){say(f);}}
 private void say(String m){if(tts==null)return;speaking=true;try{sr.cancel();}catch(Exception e){}tts.speak(m,TextToSpeech.QUEUE_FLUSH,null,"friday"+System.currentTimeMillis());h.postDelayed(()->{speaking=false;listen();},Math.max(2000,m.length()*70L));}
 public IBinder onBind(Intent i){return null;} public void onDestroy(){running=false;h.removeCallbacksAndMessages(null);if(sr!=null){sr.cancel();sr.destroy();}if(tts!=null){tts.stop();tts.shutdown();}if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}stopForeground(true);super.onDestroy();}
}

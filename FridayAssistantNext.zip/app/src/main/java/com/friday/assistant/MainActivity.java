package com.friday.assistant;
import android.Manifest; import android.app.Activity; import android.content.Intent; import android.content.pm.PackageManager; import android.net.Uri; import android.os.Bundle; import android.provider.Settings; import android.view.Gravity; import android.widget.*;

public class MainActivity extends Activity {
 private static final int REQ=101; private TextView status;
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,40,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL);
 TextView title=new TextView(this); title.setText("FRIDAY  •  JARVIS"); title.setTextSize(27); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
 TextView help=new TextView(this); help.setText("Background voice assistant prototype\\n\\nTap Start, keep the notification visible, then say “Friday” or “Jarvis”. Try “Friday, open YouTube” or “Jarvis, open WhatsApp”. Screen wake and the colorful top line are best-effort and depend on Android permissions."); help.setTextSize(16); help.setPadding(0,24,0,24); root.addView(help);
 Button overlay=new Button(this); overlay.setText("ENABLE COLORFUL TOP LINE"); overlay.setOnClickListener(v->{if(android.os.Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}else {startService(new Intent(this,AssistantOverlayService.class));status.setText("Overlay shown briefly.");}}); root.addView(overlay,new LinearLayout.LayoutParams(-1,-2));
 status=new TextView(this); status.setText("Status: stopped"); status.setPadding(0,20,0,20); root.addView(status);
 Button start=new Button(this); start.setText("START BACKGROUND LISTENING"); start.setOnClickListener(v->startFriday()); root.addView(start,new LinearLayout.LayoutParams(-1,-2));
 Button stop=new Button(this); stop.setText("STOP LISTENING"); stop.setOnClickListener(v->{stopService(new Intent(this,FridayListeningService.class));status.setText("Status: stopped");}); root.addView(stop,new LinearLayout.LayoutParams(-1,-2)); setContentView(root); }
 private void startFriday(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ);return;} if(android.os.Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){status.setText("Listening can start; allow overlay permission for the colorful line.");} startForegroundService(new Intent(this,FridayListeningService.class));status.setText("Listening; notification should appear.");}
 public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startFriday();else if(r==REQ)status.setText("Microphone permission required.");}
}

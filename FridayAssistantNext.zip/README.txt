FRIDAY ASSISTANT NEXT — prototype source
========================================

This is an incremental prototype based on the earlier background-listening project.
It adds:
- Both "Friday" and "Jarvis" wake phrase matching (Android SpeechRecognizer, online/device provider dependent).
- Best-effort screen wake request when a wake phrase command is detected.
- A short animated colorful top bar, after granting Android "Display over other apps" permission.
- Existing basic app-opening commands and English (India) speech preference.

IMPORTANT: This is NOT the complete feature set discussed in chat.
Not implemented yet: true bundled offline speech model, reliable always-on wake word engine,
custom gesture/tap workflow recording and replay, Accessibility-based automatic typing,
multi-step WhatsApp message composition, screen capture/OCR/image understanding, voice selector,
AI server answers, cloud memory storage/account, upload verification and safe local deletion,
boot auto-start, or production-grade screen wake on all Vivo/Android builds.
The app does not silently access WhatsApp private messages or other apps' private data.

Build via your existing GitHub Actions workflow after uploading this ZIP and changing the
workflow's unzip filename to FridayAssistantNext.zip. Keep your old ZIP and old APK unchanged.
After installation, grant microphone permission. To see the colored line, tap
"ENABLE COLORFUL TOP LINE" and allow "Display over other apps". Start listening.
Screen wake is best-effort; Android lock-screen/security policy may limit it.

No APK has been built or tested in this environment. Treat this as source code for testing,
not a verified release.
